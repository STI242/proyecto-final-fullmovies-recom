# 🐍 Python simple Flask REST API
### Installation
- [ ] Clone the repo
- [ ] Create environment: python3 -m venv venv
- [ ] Activate environment: source venv/bin/activate
- [ ] Install dependencies: pip install -r requirements.txt
- [ ] Execute app on terminal: python3 main.py
